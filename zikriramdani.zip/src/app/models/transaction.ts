export class Transaction {
    id: number;
    phonenumber: string;
    operator: string;
    pulsa: number;
    harga: number;
}