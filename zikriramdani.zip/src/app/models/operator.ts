export class Operator {
    id: number;
    name: string;
}