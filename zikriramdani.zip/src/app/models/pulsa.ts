export class Pulsa {
    id: number;
    pulsa: number;
    harga: string;
}