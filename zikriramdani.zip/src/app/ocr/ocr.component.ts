import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ocr',
  templateUrl: './ocr.component.html',
  styleUrls: ['./ocr.component.css']
})
export class OcrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
